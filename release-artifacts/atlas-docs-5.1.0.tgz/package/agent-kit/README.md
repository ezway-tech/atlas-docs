# Atlas Docs reference

[Agent guide](guides/agent-guide.md) · [User guide](guides/user-guide.md) · [npm usage](guides/npm.md)

The CLI manages this directory. Keep personal instructions in the library AGENTS.md.
