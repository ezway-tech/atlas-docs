# Generated reference material

Read [guides/agent-guide.md](guides/agent-guide.md). Write project documents in the library docs directory, not here.
