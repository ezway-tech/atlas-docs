"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[9374],{59374:(e,t,r)=>{r.d(t,{diagram:()=>l});var s=r(29407);r(67447),r(73202),r(3753),r(18136),r(31048),r(32803),r(68093),r(27511),r(17352),r(71438),r(71128),r(61750),r(84710),r(25914),r(39438),r(86700);var a=(0,r(34090).K)(e=>`${(0,s.tM)(e)}
  .swimlane.cluster rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),l=(0,s.ur)({defaultLayout:"swimlane",styles:a})}}]);