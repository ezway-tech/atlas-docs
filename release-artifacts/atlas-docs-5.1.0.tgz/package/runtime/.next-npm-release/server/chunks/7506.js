"use strict";exports.id=7506,exports.ids=[7506],exports.modules={7506:(a,b,c)=>{c.d(b,{diagram:()=>f});var d=c(26549);c(54125),c(16176),c(3547),c(58514),c(40534),c(62214),c(95439),c(48461),c(39390),c(71048),c(74982),c(84358),c(97536),c(50676),c(16121),c(28974);var e=(0,c(28540).K)(a=>`${(0,d.tM)(a)}
  .swimlane.cluster rect {
    stroke: ${a.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),f=(0,d.ur)({defaultLayout:"swimlane",styles:e})}};